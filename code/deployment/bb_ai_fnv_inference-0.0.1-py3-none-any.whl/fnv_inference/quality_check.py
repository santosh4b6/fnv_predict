import logging
import numpy as np
import moviepy.editor as mpe
import time
import os
import cv2
from threading import Thread
import random
# import ntpath
# import requests
# import configparser

logger = logging.getLogger('CSKU_QUALITY')
LOGI = logger.info
LOGD = logger.debug
LOGE = logger.error

class QualityCheckThread(Thread):
    def __init__(self, name, frames, txn_video_path):
        Thread.__init__(self)
        self.name = name
        self.status = 0
        self.frames = frames
        self.txn_video_path = txn_video_path

    def run(self):
        LOGD('Quality check started in background thread')
        qc = QualityCheck()
        self.status = qc.get_video_quality_check(self.frames, self.txn_video_path)
        LOGD('Quality check ended in background thread with status = %d'%(self.status))

    def returnStatus(self):
        return self.status

from .algo2_inference_utils import RESULT_STATUS


class FreezeDetection:

    def __init__(self):
        self.interval = 0.25 #seconds
        self.freeze_th = 1.5 #seconds

    def isVideohasFreeze(self, videoPath):
        LOGI('Video path: %s'%videoPath)
        st = time.time()
        video = mpe.VideoFileClip(videoPath)
        prevframe = video.get_frame(0)
        freeze_time = 0
        tot_freeze_time = 0
        max_freeze_time = 0
        for ts in np.arange(self.interval, video.duration, self.interval):
            curframe = video.get_frame(ts)
            frame_diff = np.sum(abs(prevframe - curframe))
            if not frame_diff:
                freeze_time += self.interval
            else:
                if freeze_time:
                    LOGI('segment freeze time duration: %.2fs' % freeze_time)
                    tot_freeze_time+=freeze_time
                    max_freeze_time = max(max_freeze_time, freeze_time)
                freeze_time = 0
            prevframe = curframe

        et = time.time()
        LOGI("[TIME] Total freeze time is %.2f seconds"%tot_freeze_time)
        LOGI("[TIME] Total processing time is %d seconds" % (et - st))

        if(max_freeze_time >= self.freeze_th):
            LOGE("[ERROR] Video has freezing issue")
            return True

        return False


class QualityCheck:
    def __init__(self):
        self.MIN_VIDEO_LENGTH = 6  # seconds
        # self.config = configparser.RawConfigParser()
        # self.config.read('ml.properties')
        # self.api_endpoint = self.config.get('ml', 'alert_url')
        # self.header = {self.config.get('ml', 'header_key'): self.config.get('ml', 'header_value')}

    def isVideoLenShort(self, videoPath):

        try:
            mpe_video = mpe.VideoFileClip(videoPath)
            if(mpe_video.duration < self.MIN_VIDEO_LENGTH):
                return True
        except:
            LOGE('[ERROR] in computing video duration')

        return False

    def compute_sharpness(self, img):

        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # compute the Laplacian of the image and then return the focus
        # measure, which is simply the variance of the Laplacian
        sharp_value = cv2.Laplacian(img_gray, cv2.CV_64F).var()

        return sharp_value

    def camera_focus_quality_check(self, frames):

        MAX_ANALYSIS_FRAMES = 5
        SHARPNESS_IMAGE_TH = 100

        # Compute transaction quality
        analysis_frames = min(MAX_ANALYSIS_FRAMES, len(frames))
        sharp_val = 0
        for frame in random.sample(frames, analysis_frames):
            sharp_val += (self.compute_sharpness(frame))

        if (analysis_frames):
            sharp_val //= analysis_frames
        else:
            sharp_val = 0

        LOGI('[INFO] Transaction video average sharpness value is %d' % sharp_val)

        status = RESULT_STATUS.VIDEO_QUALITY_ISUUE if (sharp_val <= SHARPNESS_IMAGE_TH) else RESULT_STATUS.SUCCESS

        return status

    def analyze_video(self, frames, videoPath):

        if (os.stat(videoPath).st_size == 0):
            LOGE("[ERROR] Video has zero KB issue")
            return RESULT_STATUS.ZERO_SIZE

        txn_video_data = cv2.VideoCapture(videoPath)
        if (not txn_video_data.isOpened()):
            LOGE('[ERROR] txn_video %s path has some issue, please check' % videoPath)
            return RESULT_STATUS.VIDEO_NOT_OPENED
        txn_video_data.release()

        #Check video length issue
        if(self.isVideoLenShort(videoPath)):
            return RESULT_STATUS.VIDEO_LEN_ISSUE

        # Check if video freezed or not
        fd = FreezeDetection()
        if fd.isVideohasFreeze(videoPath):
            return RESULT_STATUS.VIDEO_FREEZED

        #Check camera focus quality
        status = self.camera_focus_quality_check(frames)

        return status

    # def quality_check_bg_thread(self,  machineId, videoPath):
    #     status = self.analyze_video(videoPath)
    #
    #     if (status != 0):
    #         # send alert
    #         LOGE("%s has error status code %d" % (videoPath, status))
    #
    #         body =  {}
    #         body["machine_id"] = machineId
    #         body["type"] = "warn"
    #         body["code"] = str(status)
    #         body["context"] = ntpath.basename(videoPath)
    #         LOGI("Sending alert")
    #         url = os.path.join(self.api_endpoint, machineId)
    #         requests.post(url, data=None, headers = self.header,json=body)


    def get_video_quality_check(self, frames, videoPath):
        # background_thread = Thread(target=self.quality_check_bg_thread, args=(machineId, videoPath,))
        # background_thread.start()
        status = self.analyze_video(frames, videoPath)
        return status







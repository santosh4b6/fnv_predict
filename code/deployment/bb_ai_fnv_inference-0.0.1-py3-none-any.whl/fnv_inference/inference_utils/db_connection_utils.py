import MySQLdb
import mysql.connector
import os
import configparser
import warnings
warnings.filterwarnings('ignore')

import logging
logger = logging.getLogger('CSKU_ML')
LOGI = logger.info
LOGD = logger.debug
LOGE = logger.error


def connect_mysq_db():

    if(os.path.exists('ml.properties')):

        LOGI('Getting mysql db from ml.properties')
        config = configparser.RawConfigParser()
        config.read('ml.properties')

        mydb = mysql.connector.connect(host=config.get('ml', 'dbHost'),
                                          user=config.get('ml', 'dbUser'),
                                          passwd=config.get('ml', 'dbPassword'),
                                          database=config.get('ml', 'dbName'))

    else:
        LOGI('Getting mysql db from hard coded values')
        # url = 'rm-6gj5c2kj7k163e555ko.mysql.ap-south-1.rds.aliyuncs.com'
        # username = 'root'
        # password = 'welcome@kwik24'
        # database_name = 'kwik24'

        pkeyfilepath = '/home/santosh/SantoshWaddi/Cloud/kwik24_db/jump-prod-securitykey.pem'

        if(os.path.exists(pkeyfilepath)):
            LOGI('Connecting mysql db over jump server')
            import paramiko
            from sshtunnel import SSHTunnelForwarder

            pkeyfilepath = '/home/santosh/SantoshWaddi/Cloud/kwik24_db/jump-prod-securitykey.pem'
            mypkey = paramiko.RSAKey.from_private_key_file(pkeyfilepath)

            sql_hostname = 'rr-6gj1vsb60248o9d86ko.mysql.ap-south-1.rds.aliyuncs.com'
            sql_username = 'mysql_readonly'
            sql_password = 'm1e9g0a3s1t9a7r7'
            sql_main_database = 'kwik24'
            sql_port = 3306
            ssh_host = '149.129.136.228'
            ssh_user = 'root'
            ssh_port = 22

            tunnel = SSHTunnelForwarder(
                (ssh_host, ssh_port),
                ssh_username=ssh_user,
                ssh_pkey=mypkey,
                remote_bind_address=(sql_hostname, sql_port))
            tunnel.start()
            mydb = MySQLdb.connect(host='127.0.0.1', user=sql_username,
                                   passwd=sql_password, db=sql_main_database,
                                   port=tunnel.local_bind_port)
        else:
            LOGI('Connecting mysql db directly')
            url = 'rr-6gj1vsb60248o9d86ko.mysql.ap-south-1.rds.aliyuncs.com'
            username = 'mysql_readonly'
            password = 'm1e9g0a3s1t9a7r7'
            database_name = 'kwik24'

            mydb = MySQLdb.connect(host=url,
                                   database=database_name,
                                   user=username,
                                   password=password)

    return mydb


def get_ml_models_data():

    kwik24 = connect_mysq_db()

    mycursor = kwik24.cursor()
    mycursor.execute("SELECT * FROM ml_model")
    ml_model_data = mycursor.fetchall()
    ml_model_fields = [i[0] for i in mycursor.description]

    model_ind = ml_model_fields.index('model')
    algo_ind = ml_model_fields.index('algorithm')
    prodid_ind = ml_model_fields.index('product_ids')
    sm_ind = ml_model_fields.index('sigma_multiplier')
    csku_ind = ml_model_fields.index('combisku_product_id')
    model_ver_ind = ml_model_fields.index('model_version')
    min_prod_area_ind = ml_model_fields.index('min_prod_area') if 'min_prod_area' in ml_model_fields else -1
    max_prod_area_ind = ml_model_fields.index('max_prod_area') if 'max_prod_area' in ml_model_fields else -1

    model_data_dict = {}
    # Get individual csku ml models data
    for data in ml_model_data:
        model_data_dict[data[model_ind]] = {}
        model_data_dict[data[model_ind]]['product_ids'] = [int(pid) for pid in data[prodid_ind].split(',')]
        model_data_dict[data[model_ind]]['algo'] = int(data[algo_ind])
        model_data_dict[data[model_ind]]['sigma_multiplier'] = float(data[sm_ind])
        model_data_dict[data[model_ind]]['csku_productid'] = int(data[csku_ind]) if data[csku_ind] else 0
        model_data_dict[data[model_ind]]['model_version'] = data[model_ver_ind]

        model_data_dict[data[model_ind]]['min_prod_area'] = int(data[min_prod_area_ind]) if min_prod_area_ind != -1 else 0
        model_data_dict[data[model_ind]]['max_prod_area'] = int(data[max_prod_area_ind]) if max_prod_area_ind != -1 else 200000

    return model_data_dict